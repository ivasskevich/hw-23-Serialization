﻿using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Json;
using System.Xml.Serialization;


[Serializable]
[DataContract]
public class Person
{
    [DataMember]
    public string Name { get; set; }
    [DataMember]
    public string Surname { get; set; }
    [DataMember]
    public int Age { get; set; }
    [DataMember]
    public string Phone { get; set; }

    public Person() { }

    public Person(string name, string surname, int age, string phone)
    {
        Name = name;
        Surname = surname;
        Age = age;
        Phone = phone;
    }

    public virtual void Print()
    {
        Console.Write($"Name: {Name}, Surname: {Surname}, Age: {Age}, Phone: {Phone}");
    }
}

[Serializable]
[DataContract]
public class Student : Person
{
    [DataMember]
    public double Average { get; set; }
    [DataMember]
    public string Number_Of_Group { get; set; }

    public Student() { }

    public Student(string name, string surname, int age, string phone, double average, string numberOfGroup)
        : base(name, surname, age, phone)
    {
        Average = average;
        Number_Of_Group = numberOfGroup;
    }

    public override void Print()
    {
        base.Print();
        Console.WriteLine($", Average: {Average}, Group: {Number_Of_Group}");
    }

    public int CompareTo(Student other)
    {
        if (other == null) return 1;

        return Average.CompareTo(other.Average);
    }
}

[Serializable]
[DataContract]
public class Academy_Group
{
    [DataMember]
    public List<Student> Students { get; set; }

    public Academy_Group()
    {
        Students = new List<Student>();
    }

    public void Add(Student student)
    {
        Students.Add(student);
    }

    public void Remove(string surname)
    {
        var studentToRemove = Students.FirstOrDefault(s => s.Surname == surname);
        if (studentToRemove != null)
        {
            Students.Remove(studentToRemove);
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    public void Edit(string surname, Student updatedStudent)
    {
        var index = Students.FindIndex(s => s.Surname == surname);
        if (index != -1)
        {
            Students[index] = updatedStudent;
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    public void Print()
    {
        foreach (Student student in Students)
        {
            student.Print();
        }
    }

    public void SortByAverage()
    {
        Students.Sort((s1, s2) => s1.Average.CompareTo(s2.Average));
    }

    public void SortBySurname()
    {
        Students.Sort((s1, s2) => string.Compare(s1.Surname, s2.Surname, StringComparison.Ordinal));
    }

    public void Save(string filePath)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            foreach (Student student in Students)
            {
                writer.WriteLine($"{student.Name};{student.Surname};{student.Age};{student.Phone};{student.Average};{student.Number_Of_Group}");
            }
        }
    }

    public void Load(string filePath)
    {
        Students.Clear();
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                var parts = line.Split(';');
                var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), parts[5]);
                Students.Add(student);
            }
        }
    }

    public Student Search(string surname)
    {
        return Students.FirstOrDefault(s => s.Surname.Equals(surname, StringComparison.OrdinalIgnoreCase));
    }

    public void SaveAsXml(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(Academy_Group));
        using (StreamWriter writer = new StreamWriter(filePath, false))
        {
            serializer.Serialize(writer, this);
        }
    }

    public void LoadFromXml(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(Academy_Group));
        using (StreamReader reader = new StreamReader(filePath))
        {
            Academy_Group loadedGroup = (Academy_Group)serializer.Deserialize(reader);
            this.Students = loadedGroup.Students;
        }
    }

    public void SaveAsJson(string filePath)
    {
        try
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Academy_Group));
                jsonFormatter.WriteObject(fs, this);
            }
            Console.WriteLine("Data successfully saved in JSON format.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error saving data in JSON format: " + ex.Message);
        }
    }

    public void LoadFromJson(string filePath)
    {
        try
        {
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Academy_Group));
                Academy_Group loadedGroup = (Academy_Group)jsonFormatter.ReadObject(fs);
                this.Students = loadedGroup.Students;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error loading data from JSON format: " + ex.Message);
        }
    }

    public void SaveAsSoap(string filePath)
    {
        SoapFormatter formatter = new SoapFormatter();
        using (Stream stream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
        {
            formatter.Serialize(stream, this);
        }
    }

    public void LoadFromSoap(string filePath)
    {
        SoapFormatter formatter = new SoapFormatter();
        using (Stream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
        {
            Academy_Group loadedGroup = (Academy_Group)formatter.Deserialize(stream);
            this.Students = loadedGroup.Students;
        }
    }
}

class Main_Class
{
    static void Main(string[] args)
    {
        Academy_Group group = new Academy_Group();
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Remove Student");
            Console.WriteLine("3. Edit Student");
            Console.WriteLine("4. Print Group");
            Console.WriteLine("5. Sort by Average");
            Console.WriteLine("6. Sort by Surname");
            Console.WriteLine("7. Save to File");
            Console.WriteLine("8. Load from File");
            Console.WriteLine("9. Search Student by Surname");
            Console.WriteLine("10. Save data (SOAP, XML, JSON)");
            Console.WriteLine("11. Load data (SOAP, XML, JSON)");
            Console.WriteLine("12. Exit");
            Console.Write("Choose an option: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Surname: ");
                    string surname = Console.ReadLine();
                    Console.Write("Age: ");
                    int age = int.Parse(Console.ReadLine());
                    Console.Write("Phone: ");
                    string phone = Console.ReadLine();
                    Console.Write("Average: ");
                    double average = double.Parse(Console.ReadLine());
                    Console.Write("Group Number: ");
                    string groupNumber = Console.ReadLine();
                    group.Add(new Student(name, surname, age, phone, average, groupNumber));
                    break;

                case 2:
                    Console.Write("Enter surname of the student to remove: ");
                    string removeSurname = Console.ReadLine();
                    group.Remove(removeSurname);
                    break;

                case 3:
                    Console.Write("Enter surname of the student to edit: ");
                    string editSurname = Console.ReadLine();
                    Console.Write("New Name: ");
                    string newName = Console.ReadLine();
                    Console.Write("New Age: ");
                    int newAge = int.Parse(Console.ReadLine());
                    Console.Write("New Phone: ");
                    string newPhone = Console.ReadLine();
                    Console.Write("New Average: ");
                    double newAverage = double.Parse(Console.ReadLine());
                    Console.Write("New Group Number: ");
                    string newGroupNumber = Console.ReadLine();
                    group.Edit(editSurname, new Student(newName, editSurname, newAge, newPhone, newAverage, newGroupNumber));
                    break;

                case 4:
                    group.Print();
                    break;

                case 5:
                    group.SortByAverage();
                    Console.WriteLine("Sorted by average.");
                    break;

                case 6:
                    group.SortBySurname();
                    Console.WriteLine("Sorted by surname.");
                    break;

                case 7:
                    Console.Write("Enter file path to save: ");
                    string savePath = Console.ReadLine();
                    group.Save(savePath);
                    break;

                case 8:
                    Console.Write("Enter file path to load: ");
                    string loadPath = Console.ReadLine();
                    group.Load(loadPath);
                    break;

                case 9:
                    Console.Write("Enter surname to search: ");
                    string searchSurname = Console.ReadLine();
                    var foundStudent = group.Search(searchSurname);
                    if (foundStudent != null)
                    {
                        foundStudent.Print();
                    }
                    break;

                case 10:
                    Console.WriteLine("Choose format to save data:");
                    Console.WriteLine("1. XML");
                    Console.WriteLine("2. JSON");
                    Console.WriteLine("3. SOAP");
                    int saveChoice = int.Parse(Console.ReadLine());
                    Console.Write("Enter file path to save: ");
                    string savePatH = Console.ReadLine();

                    switch (saveChoice)
                    {
                        case 1:
                            group.SaveAsXml(savePatH);
                            break;
                        case 2:
                            group.SaveAsJson(savePatH);
                            break;
                        case 3:
                            group.SaveAsSoap(savePatH);
                            break;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                    break;

                case 11:
                    Console.WriteLine("Choose format to load data:");
                    Console.WriteLine("1. XML");
                    Console.WriteLine("2. JSON");
                    Console.WriteLine("3. SOAP");
                    int loadChoice = int.Parse(Console.ReadLine());
                    Console.Write("Enter file path to load: ");
                    string loadPatH = Console.ReadLine();

                    switch (loadChoice)
                    {
                        case 1:
                            group.LoadFromXml(loadPatH);
                            break;
                        case 2:
                            group.LoadFromJson(loadPatH);
                            break;
                        case 3:
                            group.LoadFromSoap(loadPatH);
                            break;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                    break;

                case 12:
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Invalid input");
                    break;
            }
        }
    }
}